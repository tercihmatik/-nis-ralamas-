TERCIHMATIK - KURULUM

GitHub deposunun ana dizinine su dosyalari yukleyin:
- index.html
- app.js
- style.css
- programs.csv
- robots.txt
- sitemap.xml

Onemli:
- programs.csv ana dizinde olmalidir (data klasorune koymayin).
- CSV basligi:
year,university,program,city,kind,scoreType,score,rank,quota
- CSV dosyasindaki ornek kayit yalnizca arama testi icindir; gercek YKS verisi degildir.
- Gercek YKS verilerini resmi kaynaklardan dogrulayip CSV'ye eklemek gerekir.

Arama: bolum veya universite adina gore.
Filtreler: yil, universite turu, puan turu, sehir.
Siralama: basari sirasi, puan, universite adi.
