const $ = id => document.getElementById(id);
let programs = [];
function parseCSV(text) {
  const rows=[]; let row=[], cell="", quoted=false;
  for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];
    if(c==='"'&&quoted&&n==='"'){cell+='"';i++;}
    else if(c==='"') quoted=!quoted;
    else if(c===','&&!quoted){row.push(cell);cell='';}
    else if((c==='\\n'||c==='\\r')&&!quoted){if(c==='\\r'&&n==='\\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell='';}
    else cell+=c;
  }
  row.push(cell);if(row.some(x=>x.trim()))rows.push(row);
  if(!rows.length)return [];
  const headers=rows.shift().map(x=>x.trim().replace(/^\\uFEFF/,'').toLowerCase());
  return rows.map(r=>{const o={};headers.forEach((h,i)=>o[h]=(r[i]||'').trim());return o;}).filter(x=>x.university||x.program);
}
function num(v){if(!v)return NaN;return Number(String(v).replace(/\\./g,'').replace(',','.'));}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(){
 const q=$('searchInput').value.trim().toLocaleLowerCase('tr'),year=$('year').value,kind=$('kind').value,type=$('scoreType').value,city=$('city').value.trim().toLocaleLowerCase('tr');
 let list=programs.filter(p=>(!q||`${p.university} ${p.program} ${p.city}`.toLocaleLowerCase('tr').includes(q))&&(!year||!p.year||p.year===year)&&(!kind||p.kind===kind)&&(!type||p.scoreType===type)&&(!city||(p.city||'').toLocaleLowerCase('tr').includes(city)));
 const sort=$('sort').value;list.sort((a,b)=>sort==='name'?(a.university||'').localeCompare(b.university||'','tr'):sort==='score'?num(b.score)-num(a.score):sort==='rank-desc'?num(b.rank)-num(a.rank):num(a.rank)-num(b.rank));
 $('resultCount').textContent=`${list.length} program listeleniyor`;
 $('results').innerHTML=list.length?list.map(p=>`<tr><td><b>${esc(p.university)}</b><br><small>${esc(p.program)}</small></td><td>${esc(p.city||'—')}</td><td>${esc(p.scoreType||'—')}</td><td>${esc(p.score||'—')}</td><td>${esc(p.rank||'—')}</td><td>${esc(p.quota||'—')}</td><td>${esc(p.year||'—')}</td></tr>`).join(''):`<tr><td colspan="7" class="empty">Sonuç bulunamadı.</td></tr>`;
}
async function loadData(){
 try{const response=await fetch('./programs.csv',{cache:'no-store'});if(!response.ok)throw new Error(`HTTP ${response.status}`);programs=parseCSV(await response.text());$('loadStatus').textContent=`${programs.length} kayıt yüklendi`;render();}
 catch(e){console.error(e);$('loadStatus').textContent='CSV yüklenemedi';$('results').innerHTML='<tr><td colspan="7">data/programs.csv dosyası bulunamadı veya okunamadı.</td></tr>';}
}
['searchInput','year','kind','scoreType','city','sort'].forEach(id=>$(id).addEventListener(id==='searchInput'||id==='city'?'input':'change',render));
$('clearSearch').addEventListener('click',()=>{$('searchInput').value='';render();});
document.querySelectorAll('[data-query]').forEach(b=>b.addEventListener('click',()=>{$('searchInput').value=b.dataset.query;render();}));
loadData();