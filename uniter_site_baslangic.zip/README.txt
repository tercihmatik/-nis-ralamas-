UNITЕР - YKS / Üniversite Rehberi başlangıç sitesi

1) GitHub hesabında yeni, public bir repository oluştur.
2) Bu ZIP içindeki tüm dosyaları repository'nin ana dizinine yükle.
3) Settings > Pages > Deploy from a branch > main > /(root) seç ve Save'e bas.
4) GitHub sana https://kullaniciadi.github.io/repository-adi/ biçiminde bir site adresi verir.
5) robots.txt ve sitemap.xml dosyalarındaki SITE-ADRESIN metnini gerçek site adresinle değiştir.
6) Google Search Console'da URL prefix olarak site adresini ekle, sahipliği doğrula ve sitemap.xml dosyasını gönder.
   Google'da görünmek hemen garanti değildir; tarama ve indeksleme zaman alabilir.

CSV VERİ ŞABLONU
year,university,program,city,kind,scoreType,score,rank,quota

Örnek satır biçimi (gerçek veri değildir; yalnızca biçimi gösterir):
2026,Örnek Üniversitesi,Hukuk,İstanbul,Devlet,EA,örnek puan,örnek sıra,örnek kontenjan

Gerçek program verilerini ÖSYM ve YÖK Atlas'tan doğrulamadan eklemeyin.
2026 taban puan/kontenjan ve başarı sırası alanlarının kaynaklarını ayrı ayrı kontrol edin.
Bu başlangıç sürümü veri uydurmaz; CSV dosyası yüklenene kadar boş sonuç gösterir.

CSV dosyası UTF-8 biçiminde ve virgülle ayrılmış olmalıdır.
Sütun adları yukarıdaki şablonla aynı olmalıdır.
